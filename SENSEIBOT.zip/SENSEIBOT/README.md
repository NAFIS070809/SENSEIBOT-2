<h1 align="center">そのメイキー <img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="40px" alt="hi"><br>WHATSAPP BOT !</h1>

<p align="center">
<img src="https://i.ibb.co/2yN4rNN/IMG-20210410-WA0048.jpg" width="100%" alt="API Giphy logo"/>
</p>

- 🌱 I’m currently learning **nothing**.

- 👀 I m currently focusing on **JavaScript**.


## Requirement

This repo require a [NodeJS](https://nodejs.org/) >= 11.15.0.


## Termux Installation

First of all, you need to install [Git](https://git-scm.com/download/win) & [NodeJS](https://nodejs.org/). Then open your git bash, and follow this:<br>
```sh
$ pkg install git
$ pkg install bash
$ pkg install nodejs
$ pkg install update && pkg install upgrade
$ git clone https://github.com/Arnando456/Rem7
$ cd Rem7
$ ls
$ bash install.sh
$ node index.js
Langsung Scan bruhh :v
```

## How to run

```sh
$ node index.js
```
or<br>
```sh
$ npm start
```

## SOSIAL MEDIA ADMIN <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/powerup.gif" width="29px">

* [`Youtube Admin`](https://youtube.com/channel/UCal0HWOurq6GIF4_z0N2B6Q)
* [`WhatsApp Admin `](https://wa.me/+6281534162316)
* [`Group WhatsApp `](https://chat.whatsapp.com/Hol7SQwX5A99GJ1ltstdWe)
## THANKS TO <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Handshake.gif" width="60px">

* [`Mr.A43G`]
* [`SofyanAmv`]
* [`Arashi~`]
* [`RamlanID`]
<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Gameplay.gif" alt="Mario Game" width="600" />